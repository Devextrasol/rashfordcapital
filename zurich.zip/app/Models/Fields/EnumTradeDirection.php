<?php

namespace App\Models\Fields;

interface EnumTradeDirection {
    const DIRECTION_BUY      = 0;
    const DIRECTION_SELL     = 1;
}