<?php

namespace App\Models\Fields;

interface EnumUserStatus {
    const STATUS_ACTIVE     = 0;
    const STATUS_BLOCKED    = 1;
}