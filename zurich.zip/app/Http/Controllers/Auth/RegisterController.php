<?php

namespace App\Http\Controllers\Auth;

use App\Rules\ReCaptchaValidationPassed;
use Carbon\Carbon;
use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/competitions';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
        $this->middleware('cookie-consent');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name'      => ['required', 'string', 'min:3', 'max:100'],
            'email'     => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password'  => ['required', 'string', 'min:6', 'confirmed'],
            'last_name' => ['required', 'string', 'min:3', 'max:100'],
            'country'   => ['required', 'string', 'min:2', 'max:200'],
            'phone'     => ['required', 'numeric', 'min:11'],
            'g-recaptcha-response' => config('settings.recaptcha.secret_key') ? ['required', new ReCaptchaValidationPassed()] : [],
        ], ['g-recaptcha-response.required' => __('auth.human')]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {
        return User::create([
            'name'              => $data['name'],
            'email'             => $data['email'],
            'last_name'             => $data['last_name'],
            'country'             => $data['country'],
            'phone'             => $data['phone'],
            'role'              => User::ROLE_USER,
            'status'            => User::STATUS_ACTIVE,
            'last_login_time'   => Carbon::now(),
            'last_login_ip'     => request()->ip(),
            'password'          => bcrypt($data['password']),
        ]);
    }

    /**
     * The user has been registered.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  mixed  $user
     * @return mixed
     */
    protected function registered(Request $request, $user)
    {
        if (config('settings.users.email_verification')) {
            return redirect($this->redirectPath())->with('success', __('auth.email_verification_notice'));
        }

        return FALSE;
    }
}
