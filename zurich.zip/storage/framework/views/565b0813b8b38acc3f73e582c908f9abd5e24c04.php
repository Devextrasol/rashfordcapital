<?php $__env->startSection('title'); ?>
  <?php echo e(__('users.leads')); ?>

<?php $__env->stopSection(); ?>
<div class="ui toggle checkbox">
  <input type="checkbox" name="public">
  <label>Auto refresh page</label>
</div>
<style>
  #leads-table_paginate{
    display: none;
  }
  .set_status {
    min-height: 26px;
    border: 1px solid #37014f69;
    border-radius: 4px;
    width: 100%;
  }

  body > .pusher {
    overflow: scroll !important;
  }

  #leads-table thead > tr:first-child > th:nth-child(1) {
  }

  .ui.basic.olive.button {
    padding: 5px 10px !important;
    margin-left: 5px !important;
    text-align: center !important;
  }

  .basic.button i {
    margin: 0px !important;
  }

</style>
<?php $__env->startSection('content'); ?>
  
  <div class="ui one column stackable grid container">
    <div class="column">
      <?php if(auth()->user()->role != 'SALES'){ ?>
      <div class="ui column grid top-filter">
        <div class="ten wide column">
          <div id="set-salesman" class="ui selection dropdown">
            <input type="hidden" name="sales_id">
            <i class="dropdown icon"></i>
            <div class="default text">Set Salesman</div>
            <div class="menu">
              <?php $roleUsers = \App\Models\User::where('role', App\Models\User::ROLE_SALES)->get(); ?>
              <?php $__currentLoopData = $roleUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user->role == App\Models\User::ROLE_SALES): ?>
                  <div class="item" data-value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>

          <div id="set-status" class="ui selection dropdown">
            <input type="hidden" name="crm_status" value="">
            <i class="dropdown icon"></i>
            <div class="default text">Set Status</div>
            <div class="menu">
              <div class="item" data-value="0"><?php echo e(__('users.crm_status_0')); ?></div>
              <div class="item" data-value="1"><?php echo e(__('users.crm_status_1')); ?></div>
              <div class="item" data-value="2"><?php echo e(__('users.crm_status_2')); ?></div>
              <div class="item" data-value="3"><?php echo e(__('users.crm_status_3')); ?></div>
              <div class="item" data-value="4"><?php echo e(__('users.crm_status_4')); ?></div>
              <div class="item" data-value="5"><?php echo e(__('users.crm_status_5')); ?></div>
              <div class="item" data-value="6"><?php echo e(__('users.crm_status_6')); ?></div>
              <div class="item" data-value="7"><?php echo e(__('users.crm_status_7')); ?></div>
            </div>
          </div>
          <button id="btn-update-bulk" class="ui button">Update Selected</button>
        </div>
        <div class="six wide column">
          <div class="ui toggle checkbox">
          <input type="checkbox" name="autrefresh" id="autrefresh" <?php echo e((session()->get('autoreffresh') == 1) ? 'checked' : ''); ?>>
          <label>Auto refresh page every 30 seconds</label>
        </div>
        </div>
      </div>
      <?php } ?>
      <table id="leads-table" class="ui selectable tablet stackable <?php echo e($inverted); ?> celled table">
        <thead>
        <tr>
          <?php $__env->startComponent('components.tables.column', ['id' => 'id']); ?>
            <?php echo e(__('users.id')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.column', ['id' => 'name']); ?>
            <?php echo e(__('users.name')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.column', ['id' => 'email']); ?>
            <?php echo e(__('users.email')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.column', ['id' => 'phone']); ?>
            <?php echo e(__('users.phone')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.column', ['id' => 'country']); ?>
            <?php echo e(__('users.country')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.column', ['id' => 'assigned']); ?>
            <?php echo e(__('users.assigned')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.column', ['id' => 'status']); ?>
            <?php echo e(__('users.status')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.column', ['id' => 'created_at']); ?>
            <?php echo e(__('users.date')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.column', ['id' => 'login']); ?>
            Login
          <?php echo $__env->renderComponent(); ?>

          
        </tr>
        </thead>
        <tbody>
        
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($user->role == App\Models\User::ROLE_USER): ?>
            <tr>
              <td data-title="<?php echo e(__('users.id')); ?>" class="user_id">
                <div class="ui checkbox">
                  <input type="checkbox" data-uid="<?php echo e($user->id); ?>">
                  <label><?php echo e($user->id); ?></label>
                </div>
                
              </td>
              <td data-title="<?php echo e(__('users.name')); ?>">
                <div style="max-width: 200px">
                <a href="<?php echo e(route('backend.users.edit', $user)); ?>">
                  <img class="ui avatar image" src="<?php echo e($user->avatar_url); ?>">
                  <?php echo e($user->name); ?> <?php echo e($user->last_name); ?>

                </a>

                <?php if($user->profiles): ?>
                  <?php $__currentLoopData = $user->profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="tooltip" data-tooltip="<?php echo e(__('app.profile_id')); ?>: <?php echo e($profile->provider_user_id); ?>">
                                            <i class="grey <?php echo e($profile->provider_name); ?> icon"></i>
                                        </span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </div>
              </td>
              <td data-title="<?php echo e(__('users.email')); ?>">
                <div style="max-width: 150px">
                <a href="mailto:<?php echo e($user->email); ?>" style="overflow-wrap: anywhere;display: block"><?php echo e($user->email); ?></a>
                </div>
              </td>
              <td data-title="<?php echo e(__('users.phone')); ?>">
                <?php echo e($user->phone); ?>

              </td>
              <td data-title="<?php echo e(__('users.country')); ?>">
                <div style="max-width: 20px"><?php echo e($user->country); ?></div>
              </td>
              <td data-title="<?php echo e(__('users.assigned')); ?>">
                <?php if( $user->sales_id == 0 ): ?>
                  Not Assigned
                <?php elseif( isset(App\Models\User::find($user->sales_id)->name) ): ?>
                  <?php echo e(App\Models\User::find($user->sales_id)->name); ?>

                <?php else: ?>
                  Not exists
                <?php endif; ?>
              </td>
              <td data-title="<?php echo e(__('users.status')); ?>" class="status">
                <div id="user-status-dropdown" class="ui selection dropdown compact" style="max-width: 200px">
                  <input type="hidden" name="crm_status" value="<?php echo e($user->crm_status); ?>">
                  <i class="dropdown icon"></i>
                  <div class="default text"></div>
                  <div class="menu">
                    <div class="item" data-value="0"><?php echo e(__('users.crm_status_0')); ?></div>
                    <div class="item" data-value="1"><?php echo e(__('users.crm_status_1')); ?></div>
                    <div class="item" data-value="2"><?php echo e(__('users.crm_status_2')); ?></div>
                    <div class="item" data-value="3"><?php echo e(__('users.crm_status_3')); ?></div>
                    <div class="item" data-value="4"><?php echo e(__('users.crm_status_4')); ?></div>
                    <div class="item" data-value="5"><?php echo e(__('users.crm_status_5')); ?></div>
                    <div class="item" data-value="6"><?php echo e(__('users.crm_status_6')); ?></div>
                    <div class="item" data-value="7"><?php echo e(__('users.crm_status_7')); ?></div>
                  </div>
                </div>

              </td>
              <td data-title="<?php echo e(__('users.date')); ?>">
                <?php echo e((strpos($user->created_at , ' ') !== false ) ? @reset(@explode(' ', $user->created_at)) : $user->created_at); ?>

                <button class="ui olive basic button" type="button" onclick="return showComment('<?php echo e($user->id); ?>' , '<?php echo e(base64_encode($user->trader_com)); ?>' , '<?php echo e($user->name); ?>', '<?php echo e(base64_encode($user->leads_com)); ?>' )"><i class="comment icon"></i></button>
              </td>
              <td data-title="Login">
                <?php
                  $parameter =[
                          'id' =>$user->id,
                      ];
                  $parameter= Crypt::encrypt($parameter);
                ?>
                <a target="_blank" class="btn bb-l btn-success btn-sm" style="" href="<?php echo e(url('/admin/impersonate',$parameter)); ?>">Login</a>
              </td>
            </tr>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

      </table>
      <?php echo e($users->render()); ?>


      
      <div class="ui modal">
        <i class="close icon"></i>
        <div class="header">
          Add Comment <span id="user_name"></span>
        </div>
        <div class="image content">

          <div class="description" style="width: 100%;">
            <div class="ui header">
              <!-- simple form -->
              <form class="" role="form" method="post" action="">
                <input type="hidden" name="id" value="" id="user_id"/>
                <input type="hidden" name="col" value="trader_com" id="col"/>
                <?php echo e(csrf_field()); ?>

                <p id="leadCom"></p>
                <p id="user_com_pre"></p>
                <textarea name="val" id="user_com" cols="30" rows="10" id="user_com" style="margin: 0px;width: 806px;height: 118px;"></textarea>
                <p>
                  <br>
                  <button class="ui positive right labeled icon button" type="button" onclick="return updateCommnt(this)"> Update <i class="checkmark icon"></i></button>
                </p>
              </form>

            </div>
          </div>
        </div>
        <div class="actions">

        </div>
      </div>

    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script>

    //function for updating status and salesperson using bulkupdate
    function updateUser(type, users, setSalesman, setStatus) {
      var data = {
        type: type,
        users: users,
        sales_id: setSalesman,
        crm_status: setStatus,
        _token: "<?php echo e(csrf_token()); ?>"
      }

      //console.log(data);

      $.ajax({
        url: "<?php echo e(url('/admin/users/fast_update/')); ?>",
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        type: 'post',
        data: data,
        success: function(data) {
          //console.log(data);

          Swal.fire({
            icon: 'success',
            title: 'Success',
            text: 'Status Changed Succesfully',
            footer: '<a href="mailto:admin@fxtrade-now.com">Please contact support</a>'
          }).then(function() {
            window.location.reload(true);
          });


          //location.reload();
        },
        error: function(request, error) {
          //console.log("Request: " + JSON.stringify(request));
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Something went wrong!',
            footer: '<a href="mailto:info@krytoconnection.com">Please contact support</a>'
          });
        }
      });


    }


    $(document).ready(function() {

      // Start Code for datatable
      $.fn.dataTableExt.ofnSearch['html-input'] = function(value) {
        // console.log(value);

        var newVal = $('.selected', value).text().trim();
        // console.log(newVal);
        return newVal;
      };


      $('#leads-table thead tr').clone(true).appendTo('#leads-table thead');
      $('#leads-table thead tr:eq(1) th').each(function(i) {

        var title = $(this).text().trim();
        if(title == 'Status') {
          var select = $('<select class="ui selection compact dropdown"><option value=" ">All</option></select>');

          $('#leads-table tr:nth-child(3) td.status .item').each(function() {
            var text = $(this).text().trim();
            select.append('<option value="' + text + '">' + text + '</option>');
          });

          $(this).html(select);
          select.dropdown();
        } else if(title == 'ID') {
          $(this).html('<div class="ui checkbox"><input type="checkbox"  id="check-all"><label></label></div>');
        } else if(title == 'Login') {
          $(this).html('');
        } else {
          $(this).html('<div class="field "><div class="fluid ui input"><input type="text"></div></div>');
        }


        $('select, input[type="text"]', this).on('keyup change', function() {

          if(table.column(i).search() !== this.value) {
            table
              .column(i)
              .search(this.value)
              .draw();
          }
        });
      });

      var table = $('#leads-table').DataTable({
        columnDefs: [
          {"type": "html-input", "targets": [6]}
        ],
        "pageLength": 100,
        orderCellsTop: true,
        fixedHeader: true,
        "order": [[0, "desc"]]

      });
      // end Code for datatable

      $('#leads-table input[name="crm_status"]').change(function() {
        //console.log("trigger");
        var obj = $(this);
        var name = obj.attr('name');
        var users = obj.closest('tr').find('.user_id').text().trim();
        var setStatus = obj.val();

        updateUser('crm_status', users, '', setStatus);

      });

      //Check all checkboxes
      $('#check-all').on('change', function() {
        if(this.checked) {
          $('#leads-table tbody tr input[type="checkbox"]').each(function() {
            $(this).prop('checked', true);
          });
        } else {
          $('#leads-table tbody tr input[type="checkbox"]').each(function() {
            $(this).prop('checked', false);
          });
        }
      });


      //Trigger update bulk
      $('#btn-update-bulk').on('click', function() {
        var setSalesman = $('#set-salesman').dropdown('get value');
        var setStatus = $('#set-status').dropdown('get value');

        var users = [];
        $("#leads-table [type='checkbox']:checked").each(function() {
          users[users.length] = $(this).attr('data-uid');
        });
        if((users.length > 0) && (setSalesman || setStatus)) {
          updateUser('bulk', users, setSalesman, setStatus);
        } else {

          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Please make sure to select at least one row and action(s) to perform!',
            footer: '<a href="mailto:info@krytoconnection.com">Have questions? Contact Support</a>'
          });
        }

        //destroy changes at the end
        $('#set-salesman, #set-status').dropdown('clear');
        $('#leads-table .checkbox.checked').checkbox('set unchecked');
      });
      $('#autrefresh').on('change', function() {
        $.post('<?php echo e(action('Backend\UserController@updateSessionAutorefresh')); ?>', {
          _token: '<?php echo e(csrf_token()); ?>',
          isValue: (($("#autrefresh").prop('checked')) ? 1 : 0)
        }, function(res) {
          console.log(res);
        });
      });
      /*refesh every 30 seconds*/
      setInterval(function() {
        let con = $("#autrefresh").prop('checked');
        if(con == true) {
          window.location.reload();
        }
      }, 30 * 1000);
    });

    function showComment(userId, com, name , leadCom) {
      $('.ui.modal').modal('show');
      $('#user_id').val(userId);
      $('#user_com_pre').html(atob(com));
      $('#user_name').text(name);
      $('#leadCom').html(atob(leadCom));
    }

    function updateCommnt(e) {
      let formData = $(this).closest('form');
      var dt = new Date();
      $.post('<?php echo e(url('admin/user/updateComment')); ?>', {
        id: $('html').find('#user_id').val(),
        col: $('html').find('#col').val(),
        val: ( (($('#user_com_pre').text().trim() != '')? $('#user_com_pre').text() + '</br>':'') + $('html').find('#user_com').val() + ' @ User : <?php echo e(auth()->user()->email); ?> at <small>' + dt.toLocaleString() + '</samll>'),
        _token: '<?php echo e(csrf_token()); ?>',
      }, function(res) {
        $('.ui.modal').modal('hide');
        window.location.reload();
        console.log(res);
      });
    }

    /*if there is a user then we need to update that*/
    $('html').on('change', '.set_status', function() {
      let postable = $(this).closest('form').serialize();
      $.ajax({
        url: "<?php echo e(url('/admin/users/update_status/')); ?>",
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        type: 'post',
        data: postable,
        success: function(data) {
          console.log(data);
          Swal.fire({
            icon: 'success',
            title: 'Success',
            text: 'Status Changed Succesfully',
            footer: '<a href="mailto:admin@fxtrade-now.com">Please contact support</a>'
          }).then(function() {
            window.location.reload(true);
          });


          //location.reload();
        },
        error: function(request, error) {
          //console.log("Request: " + JSON.stringify(request));
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Something went wrong!',
            footer: '<a href="mailto:info@krytoconnection.com">Please contact support</a>'
          });
        }
      });
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>