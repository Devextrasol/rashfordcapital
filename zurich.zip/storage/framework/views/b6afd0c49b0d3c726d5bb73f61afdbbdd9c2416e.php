<a href="<?php echo e(route('frontend.account.show', [Auth::user()])); ?>" class="item <?php echo e(Route::currentRouteName()=='frontend.account.show' ? 'active' : ''); ?>" >
    <i class="list alternate outline icon"></i>
    <?php echo e(__('accounting::text.my_account')); ?>

</a>
