<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/semantic/semantic.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/dataTables.semanticui.min.css">

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
<?php echo $__env->yieldPushContent('styles'); ?>