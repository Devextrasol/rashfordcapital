<?php
    $competition = \App\Models\Competition::all()->last();
?>

<ul class="sidebar-nav">
    <?php if(auth()->check()): ?>
        <li class="item-account">
            <?php echo $__env->make("accounting::includes.frontend.header", array_except(get_defined_vars(), array("__data", "__path")))->render();?>
        </li>
    <?php endif; ?>
        <li class="item-trade">
            <a href="<?php echo e(route('frontend.competitions.index')); ?>" class="item <?php echo e(Route::currentRouteName()=='frontend.competitions.show' ? 'active' : ''); ?>">

            
                <?php echo e(__('app.trade')); ?>

            </a>
        </li>
    

    
        <li class="item-trade-history">
            <a href="<?php echo e(route('frontend.competitions.history', $competition)); ?>" class="item <?php echo e(Route::currentRouteName()=='frontend.competitions.history' ? 'active' : ''); ?>">
                <?php echo e(__('app.history')); ?>

            </a>
        </li>
    

    <li class="item-coins">
        <a href="<?php echo e(route('frontend.assets.index')); ?>" class="item <?php echo e(Route::currentRouteName()=='frontend.assets.index' ? 'active' : ''); ?>">
            <?php echo e(__('app.coins')); ?>

        </a>
    </li>

    <?php if(config('broadcasting.connections.pusher.key')): ?>
        <li class="item-support">
            <a href="<?php echo e(route('frontend.chat.index')); ?>" class="item <?php echo e(Route::currentRouteName()=='frontend.chat.index' ? 'active' : ''); ?>">
                <?php echo e(__('app.chat')); ?>

            </a>
        </li>
    <?php endif; ?>
</ul>