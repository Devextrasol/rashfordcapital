<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/semantic/semantic.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/izitoast/iziToast.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
<?php echo $__env->yieldPushContent('styles'); ?>