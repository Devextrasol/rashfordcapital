<?php return [
  'balance_not_sufficient' => 'Stav vašich prostriedkov nie je dostatočný, aby sa zapojili do tejto súťaže.',
  'fees_paid' => 'Poplatky zaplatené',
  'reward_paid' => 'Odmenu vypláca',
];