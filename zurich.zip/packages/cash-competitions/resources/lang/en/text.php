<?php

return [
    'balance_not_sufficient' => 'Your balance is not sufficient to join this competition.',
    'fees_paid' => 'Fees paid',
    'reward_paid' => 'Reward paid',
];