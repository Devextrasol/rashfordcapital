<?php return [
  'balance_not_sufficient' => 'Ditt saldo är inte tillräckligt för att gå med i denna tävling.',
  'fees_paid' => 'Avgifter',
  'reward_paid' => 'Belöningen betalas',
];