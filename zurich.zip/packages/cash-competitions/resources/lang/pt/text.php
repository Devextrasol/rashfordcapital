<?php return [
  'balance_not_sufficient' => 'O seu saldo não for suficiente para aderir a este concurso.',
  'fees_paid' => 'Honorários pagos',
  'reward_paid' => 'Recompensa pago',
];