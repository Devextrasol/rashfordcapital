<?php return [
  'balance_not_sufficient' => 'Vaše dobroimetje ne zadostuje, da se pridružijo tej konkurenci.',
  'fees_paid' => 'Pristojbine, plačane',
  'reward_paid' => 'Nagrada izplača',
];