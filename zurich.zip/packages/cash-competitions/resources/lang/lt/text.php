<?php return [
  'balance_not_sufficient' => 'Jūsų balansas yra pakankamai prisijungti prie šio konkurso.',
  'fees_paid' => 'Mokami mokesčiai',
  'reward_paid' => 'Atlygis mokamas',
];