<?php return [
  'balance_not_sufficient' => 'Váš kredit není dostačující, aby se k této soutěži.',
  'fees_paid' => 'Poplatky placené',
  'reward_paid' => 'Odměna vyplacena',
];