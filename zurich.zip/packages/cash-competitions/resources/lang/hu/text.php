<?php return [
  'balance_not_sufficient' => 'Az egyenleged nem elegendő, hogy csatlakozzon ez a verseny.',
  'fees_paid' => 'Fizetett díjak',
  'reward_paid' => 'Jutalmat fizetett',
];