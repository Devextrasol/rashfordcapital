<?php return [
  'balance_not_sufficient' => 'Teie saldo ei ole piisav, et liituda selle konkurentsi.',
  'fees_paid' => 'Makstud tasud',
  'reward_paid' => 'Tasu makstud',
];