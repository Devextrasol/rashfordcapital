<?php return [
  'balance_not_sufficient' => 'Su saldo no es suficiente para unirse a esta competencia.',
  'fees_paid' => 'Los honorarios pagados',
  'reward_paid' => 'La recompensa pagada',
];