<?php

namespace Packages\Accounting\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentGateway extends Model
{
    //
}
