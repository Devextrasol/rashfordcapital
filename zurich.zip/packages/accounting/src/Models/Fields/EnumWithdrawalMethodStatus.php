<?php

namespace Packages\Accounting\Models\Fields;

interface EnumWithdrawalMethodStatus {
    const STATUS_ACTIVE     = 0;
    const STATUS_BLOCKED    = 1;
}