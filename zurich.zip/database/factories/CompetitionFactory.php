<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Competition::class, function (Faker $faker) {
    return [
        //
    ];
});
