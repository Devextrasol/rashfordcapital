<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Trade::class, function (Faker $faker) {
    return [
        //
    ];
});