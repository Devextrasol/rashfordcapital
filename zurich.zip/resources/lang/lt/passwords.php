<?php return [
  'password' => 'Slaptažodžiai turi būti bent šešių ženklų ir atitikties patvirtinimo.',
  'reset' => 'Jūsų slaptažodis buvo iš naujo!',
  'sent' => 'Mes turime e-paštu savo slaptažodžio nuorodą!',
  'token' => 'Tai, slaptažodžio žetonas yra neteisinga.',
  'user' => 'Mes negalime rasti vartotojas su tuo e-pašto adresą.',
];