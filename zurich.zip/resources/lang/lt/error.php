<?php return [
  'title' => 'Klaida įvyko',
  '401' => 'Neaiški',
  '404' => 'Nerastas',
  '500' => 'Vidinė serverio klaida',
];