<?php return [
  'email' => 'Licencijos turėtojas (licenciatas) el. paštas',
  'purchase_code' => 'Pirkimo kodas',
  'registration' => 'Licencijos registracija',
  'registration_success' => 'Jūsų licencija yra sėkmingai užsiregistravote!',
  'register' => 'Užsiregistruoti',
  'warning' => 'Prašome užsiregistruoti savo licenciją ir toliau naudoti programą.',
];