<?php return [
  'error' => 'Ten buvo klaida, siunčiant elektroniniu paštu. Prašome susisiekti su svetainės paramą arba bandykite dar kartą vėliau.',
  'greeting' => 'Sveiki,',
  'greeting_error' => 'Šūksniais',
  'raw_link' => 'Jei jums iškilo problemų paspaudę :action mygtuką, nukopijuokite ir įklijuokite URL toliau į savo interneto naršyklę: :url',
  'reserved' => 'Visos teisės saugomos.',
];