<?php return [
  'previous' => '&laquo; Ankstesnis',
  'next' => 'Šalia &raquo;',
];