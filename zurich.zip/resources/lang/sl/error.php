<?php return [
  'title' => 'Prišlo je prikradel',
  '401' => 'Nepooblaščeno',
  '404' => 'Ni najdeno',
  '500' => 'Notranja napaka strežnika',
];