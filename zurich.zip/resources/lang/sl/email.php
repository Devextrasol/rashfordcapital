<?php return [
  'error' => 'Prišlo je do napake pri pošiljanju e-pošte. Obrnite se na spletni strani za podporo ali poskusite znova pozneje.',
  'greeting' => 'Pozdravljeni,',
  'greeting_error' => 'Ups',
  'raw_link' => 'Če imate težave s klikom :action gumb, kopirajte URL in ga prilepite v nadaljevanju v svoj spletni brskalnik: :url',
  'reserved' => 'Vse pravice pridržane.',
];