<?php return [
  'previous' => '&laquo; Prejšnji',
  'next' => 'Naslednji &raquo;',
];