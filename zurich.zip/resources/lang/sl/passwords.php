<?php return [
  'password' => 'Gesla morajo biti vsaj šest znakov in tekmo potrditev.',
  'reset' => 'Vaše geslo je bil reset!',
  'sent' => 'Imamo e-pošti za ponastavitev gesla povezavo!',
  'token' => 'To za ponastavitev gesla žeton, je neveljaven.',
  'user' => 'Ne moremo najti uporabnik s tem e-poštni naslov.',
];