<?php return [
  'email' => 'Dovoljenje imetnika (licence) e-pošta',
  'purchase_code' => 'Nakup kodo',
  'registration' => 'Licenco za registracijo',
  'registration_success' => 'Vaše licence je uspešno registrirana!',
  'register' => 'Register',
  'warning' => 'Prosimo, da se registrirate svojo licenco, če želite še naprej uporabljati aplikacijo.',
];