<?php return [
  'password' => 'Las contraseñas deben tener al menos seis caracteres y el partido de la confirmación.',
  'reset' => 'Su contraseña se ha restablecido!',
  'sent' => 'Tenemos por correo electrónico el enlace de restablecimiento de contraseña!',
  'token' => 'Este token de recuperación de contraseña no es válida.',
  'user' => 'No podemos encontrar un usuario con ese e-mail.',
];