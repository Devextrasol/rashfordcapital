<?php return [
  'error' => 'Hubo un error al enviar el correo electrónico. Póngase en contacto con el sitio web de soporte o inténtelo de nuevo más tarde.',
  'greeting' => 'Hola',
  'greeting_error' => 'Whoops',
  'raw_link' => 'Si usted está teniendo problemas para hacer clic en el :action botón, copia y pega la siguiente URL en tu navegador: :url',
  'reserved' => 'Todos los derechos reservados.',
];