<?php return [
  'title' => 'Ha producido un error',
  '401' => 'No autorizado',
  '404' => 'No se encuentra',
  '500' => 'Error interno del servidor',
];