<?php return [
  'email' => 'Titular de la licencia (licenciatario) correo electrónico',
  'purchase_code' => 'Compra el código de',
  'registration' => 'Registro de licencias',
  'registration_success' => 'Su licencia se ha registrado correctamente!',
  'register' => 'Registro',
  'warning' => 'Por favor, registre su licencia para seguir utilizando la aplicación.',
];