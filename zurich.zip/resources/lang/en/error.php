<?php

return [
    'title' => 'An error has occured',
    '401' => 'Unauthorized',
    '404' => 'Not found',
    '500' => 'Internal server error',
];