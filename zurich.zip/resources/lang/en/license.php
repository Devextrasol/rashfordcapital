<?php

return [
    'email' => 'License holder (licensee) email',
    'purchase_code' => 'Purchase code',
    'registration' => 'License registration',
    'registration_success' => 'Your license is successfully registered!',
    'register' => 'Register',
    'warning' => 'Please register your license to continue using the application.',
];