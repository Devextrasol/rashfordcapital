<?php

return [
    'error' => 'There was an error while sending the email. Please contact the website support or try again later.',
    'greeting' => 'Hello',
    'greeting_error' => 'Whoops',
    'raw_link' => 'If you’re having trouble clicking the :action button, copy and paste the URL below into your web browser: :url',
    'reserved' => 'All rights reserved.',
];