<?php return [
  'previous' => '&laquo; Vorherige',
  'next' => 'Weiter &raquo;',
];