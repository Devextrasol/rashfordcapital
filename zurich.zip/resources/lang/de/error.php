<?php return [
  'title' => 'Es ist ein Fehler aufgetreten',
  '401' => 'Unbefugte',
  '404' => 'Nicht gefunden',
  '500' => 'Internal server error',
];