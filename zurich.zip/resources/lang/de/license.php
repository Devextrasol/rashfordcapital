<?php return [
  'email' => 'Lizenznehmers (der Lizenznehmer) E-Mail',
  'purchase_code' => 'Kauf-code',
  'registration' => 'Lizenz-Registrierung',
  'registration_success' => 'Ihre Lizenz wurde erfolgreich registriert!',
  'register' => 'Registrieren',
  'warning' => 'Bitte registrieren Sie Ihre Lizenz, um weiterhin mit der Anwendung.',
];