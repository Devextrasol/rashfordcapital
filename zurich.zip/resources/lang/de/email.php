<?php return [
  'error' => 'Es wurde ein Fehler beim versenden der E-Mail. Bitte Kontaktieren Sie den website-support oder versuchen Sie es später erneut.',
  'greeting' => 'Hallo',
  'greeting_error' => 'Whoops',
  'raw_link' => 'Wenn Sie Probleme beim klicken auf die :action - button, kopieren Sie die URL und fügen Sie in Ihre web-browser: :url',
  'reserved' => 'Alle Rechte vorbehalten.',
];