<?php return [
  'error' => 'Der opstod en fejl under afsendelse af e-mail. Kontakt venligst hjemmesiden støtte, eller prøv igen senere.',
  'greeting' => 'Hej',
  'greeting_error' => 'Whoops',
  'raw_link' => 'Hvis du har problemer med at klikke :action - knappen, skal du kopiere og indsætte WEBADRESSEN nedenfor ind i din browser: :url',
  'reserved' => 'Alle rettigheder forbeholdes.',
];