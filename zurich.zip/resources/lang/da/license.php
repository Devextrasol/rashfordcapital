<?php return [
  'email' => 'Certifikatindehaver (licenstageren) e-mail',
  'purchase_code' => 'Køb kode',
  'registration' => 'Registrering',
  'registration_success' => 'Din licens er blevet registreret!',
  'register' => 'Registrer dig',
  'warning' => 'Du registrere din licens til at fortsætte med at bruge programmet.',
];