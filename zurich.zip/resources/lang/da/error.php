<?php return [
  'title' => 'Der er opstået en fejl',
  '401' => 'Uautoriseret',
  '404' => 'Ikke fundet',
  '500' => 'Intern server fejl',
];