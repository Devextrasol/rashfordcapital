<?php return [
  'password' => 'Adgangskoden skal være på mindst seks tegn og matche bekræftelse.',
  'reset' => 'Din adgangskode er blevet nulstillet!',
  'sent' => 'Vi har sendt e-mail til nulstilling af adgangskoden link!',
  'token' => 'Dette password reset token er ugyldige.',
  'user' => 'Vi kan ikke finde en bruger med denne e-mail-adresse.',
];