<?php return [
  'previous' => '&laquo; Tidligere',
  'next' => 'Næste &raquo;',
];