<?php return [
  'error' => 'Er is een fout opgetreden tijdens het versturen van de e-mail. Neem contact op met de website-ondersteuning of probeer het later opnieuw.',
  'greeting' => 'Hallo',
  'greeting_error' => 'Oeps',
  'raw_link' => 'Als u problemen ondervindt bij het klikken op de :action knop, kopieer en plak onderstaande URL in uw webbrowser: :url',
  'reserved' => 'Alle rechten voorbehouden.',
];