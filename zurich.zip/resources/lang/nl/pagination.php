<?php return [
  'previous' => '&laquo; Vorig',
  'next' => 'Next &raquo;',
];