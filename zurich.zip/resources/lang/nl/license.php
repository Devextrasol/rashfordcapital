<?php return [
  'email' => 'Licentie houder (licentiehouder) e-mail',
  'purchase_code' => 'Koop-code',
  'registration' => 'Licentie registratie',
  'registration_success' => 'Uw licentie is succesvol geregistreerd!',
  'register' => 'Registreren',
  'warning' => 'Registreer uw licentie het programma wilt blijven gebruiken.',
];