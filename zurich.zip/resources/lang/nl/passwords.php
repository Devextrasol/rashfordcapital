<?php return [
  'password' => 'Wachtwoorden moeten uit ten minste zes tekens en overeenkomen met de bevestiging.',
  'reset' => 'Uw wachtwoord is gereset!',
  'sent' => 'We hebben een e-mail ontvangen met uw wachtwoord reset link!',
  'token' => 'Dit wachtwoord te resetten token is ongeldig.',
  'user' => 'We kunnen het niet vinden van een gebruiker met het e-mail adres.',
];