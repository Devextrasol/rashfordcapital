<?php return [
  'title' => 'Er is een fout opgetreden',
  '401' => 'Ongeautoriseerd',
  '404' => 'Niet gevonden',
  '500' => 'Interne server fout',
];