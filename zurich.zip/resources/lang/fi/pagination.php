<?php return [
  'previous' => '&laquo; Edellinen',
  'next' => 'Seuraava &raquo;',
];