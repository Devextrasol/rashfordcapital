<?php return [
  'password' => 'Salasanan on oltava vähintään kuusi merkkiä ja ottelu vahvistus.',
  'reset' => 'Salasanasi on nollattu!',
  'sent' => 'Meillä on e-postitetaan salasanasi palautuslinkki!',
  'token' => 'Tämän salasanan palautustiedostoja on virheellinen.',
  'user' => 'Emme voi löytää käyttäjälle, että e-mail osoite.',
];