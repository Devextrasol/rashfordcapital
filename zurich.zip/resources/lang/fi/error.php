<?php return [
  'title' => 'Virhe on tapahtunut',
  '401' => 'Luvaton',
  '404' => 'Ei löytynyt',
  '500' => 'Internal server error',
];