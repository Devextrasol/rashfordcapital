<?php return [
  'error' => 'Siellä oli virhe, kun lähetät sähköpostia. Ota yhteyttä sivuston tukea tai yritä myöhemmin uudelleen.',
  'greeting' => 'Hei',
  'greeting_error' => 'Oho',
  'raw_link' => 'Jos sinulla on ongelmia klikkaamalla :action - painike, kopioi ja liitä URL-osoite alla selaimeesi: :url',
  'reserved' => 'Kaikki oikeudet pidätetään.',
];