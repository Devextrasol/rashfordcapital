<?php return [
  'email' => 'Lisenssin haltijalla (luvanhaltija) sähköposti',
  'purchase_code' => 'Purchase code',
  'registration' => 'Lisenssin rekisteröinti',
  'registration_success' => 'Lisenssi on rekisteröity!',
  'register' => 'Rekisteriin',
  'warning' => 'Ota rekisteröi lisenssi, jos haluat jatkaa sovelluksen.',
];