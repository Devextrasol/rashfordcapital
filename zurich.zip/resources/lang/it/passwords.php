<?php return [
  'password' => 'Le password devono essere di almeno sei caratteri e soddisfare la conferma.',
  'reset' => 'La tua password è stata reimpostata!',
  'sent' => 'Abbiamo inviato e-mail il link di reimpostazione password!',
  'token' => 'Questa password reset token non valido.',
  'user' => 'Non siamo in grado di trovare un utente con l\'indirizzo di posta elettronica.',
];