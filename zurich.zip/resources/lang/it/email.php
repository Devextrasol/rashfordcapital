<?php return [
  'error' => 'C\'è stato un errore durante l\'invio dell\'email. Si prega di contattare il sito web di supporto o riprovare più tardi.',
  'greeting' => 'Ciao',
  'greeting_error' => 'Whoops',
  'raw_link' => 'Se hai problemi cliccando %<<0>> il tasto%, copia e incolla il seguente URL nel tuo browser: :url',
  'reserved' => 'Tutti i diritti riservati.',
];