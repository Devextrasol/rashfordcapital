<?php return [
  'title' => 'Si è verificato un errore',
  '401' => 'Non autorizzato',
  '404' => 'Non trovato',
  '500' => 'Errore interno del server',
];