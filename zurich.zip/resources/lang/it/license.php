<?php return [
  'email' => 'Titolare della licenza (licenza), e-mail',
  'purchase_code' => 'Acquisto codice',
  'registration' => 'La registrazione della licenza',
  'registration_success' => 'La licenza è registrato correttamente!',
  'register' => 'Registro',
  'warning' => 'Si prega di registrare la licenza per continuare a utilizzare l\'applicazione.',
];