<style>
  .openpricechange {
    padding: 5px;
    border: 1px solid #cfd2d5;
    border-radius: 5px;
    max-width: 156px;
  }
</style>
<?php $__env->startSection('content'); ?>
  <div class="ui stackable grid container-fluid">
    <div class="tablet only computer only three wide column">
      <?php echo $__env->make('pages.frontend.competitions.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="ui thirteen wide column tablet stackable">
      <h1 class="ui blue header">Trade <?php echo e(__('app.history')); ?></h1>
      <div class="column">
        <?php if($trades->isEmpty()): ?>
          <div class="ui segment">
            <p><?php echo e(__('app.no_closed_trades')); ?></p>
          </div>
        <?php else: ?>
          <table class="ui selectable tablet stackable <?php echo e($inverted); ?> table">
            <thead>
            <tr>
              <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'asset', 'sort' => $sort, 'order' => $order]); ?>
                <?php echo e(__('app.asset')); ?>

              <?php echo $__env->renderComponent(); ?>
              <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'direction', 'sort' => $sort, 'order' => $order]); ?>
                <?php echo e(__('app.buy_sell')); ?>

              <?php echo $__env->renderComponent(); ?>
              <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'volume', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
                <?php echo e(__('app.volume')); ?>

              <?php echo $__env->renderComponent(); ?>
              <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'price_open', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
                <?php echo e(__('app.open_price')); ?>, <?php echo e($competition->currency->code); ?>

              <?php echo $__env->renderComponent(); ?>
              <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'price_close', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
                <?php echo e(__('app.close_price')); ?>, <?php echo e($competition->currency->code); ?>

              <?php echo $__env->renderComponent(); ?>
              <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'pnl', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
                <?php echo e(__('app.pnl')); ?>, <?php echo e($competition->currency->code); ?>

              <?php echo $__env->renderComponent(); ?>
              <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'created', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
                <?php echo e(__('app.created_at')); ?>

              <?php echo $__env->renderComponent(); ?>
              <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'closed', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
                <?php echo e(__('app.closed_at')); ?>

              <?php echo $__env->renderComponent(); ?>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td data-title="<?php echo e(__('app.asset')); ?>">
                  <img src="<?php echo e($trade->asset->logo_url); ?>" class="ui avatar image">
                  <?php echo e($trade->asset->symbol); ?>

                  (<?php echo e($trade->asset->name); ?>)
                </td>
                <td data-title="<?php echo e(__('app.buy_sell')); ?>">
                  <?php if($trade->direction == \App\Models\Trade::DIRECTION_BUY): ?>
                    <span class="ui tiny basic green label">
                                        <i class="arrow up icon"></i>
                                        <?php echo e(__('app.trade_direction_' . \App\Models\Trade::DIRECTION_BUY)); ?>

                                    </span>
                  <?php else: ?>
                    <span class="ui tiny basic red label">
                                        <i class="arrow down icon"></i>
                                        <?php echo e(__('app.trade_direction_' . \App\Models\Trade::DIRECTION_SELL)); ?>

                                    </span>
                  <?php endif; ?>
                </td>
                <td data-title="<?php echo e(__('app.volume')); ?>" class="right aligned"><?php echo e($trade->_volume); ?></td>
                <td data-title="<?php echo e(__('app.open_price')); ?>" class="right aligned">
                  <?php if(in_array(auth()->user()->role, ['ADMIN', 'FLOOR_MANAGER'])): ?>
                    
                    <?php echo e($trade->_price_open); ?>

                  <?php else: ?>
                    <?php echo e($trade->_price_open); ?>

                  <?php endif; ?>


                </td>
                <td data-title="<?php echo e(__('app.close_price')); ?>" class="right aligned"><?php echo e($trade->_price_close); ?></td>
                <td data-title="<?php echo e(__('app.pnl')); ?>" class="<?php echo e($trade->pnl > 0 ? 'positive' : ($trade->pnl < 0 ? 'negative' : '')); ?> right aligned">
                  <?php echo e($trade->_pnl); ?>

                </td>
                <td data-title="<?php echo e(__('app.created_at')); ?>" class="right aligned">
                  <?php echo e($trade->created_at->diffForHumans()); ?>

                  <span data-tooltip="<?php echo e($trade->created_at); ?>" <?php echo e($inverted ? 'data-inverted="false"' : ''); ?>>
                                    <i class="calendar outline tooltip icon"></i>
                                </span>
                </td>
                <td data-title="<?php echo e(__('app.closed_at')); ?>" class="right aligned">
                  <?php echo e($trade->closed_at->diffForHumans()); ?>

                  <span data-tooltip="<?php echo e($trade->closed_at); ?>" <?php echo e($inverted ? 'data-inverted="false"' : ''); ?>>
                                    <i class="calendar outline tooltip icon"></i>
                                </span>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
      <div class="right aligned column">
        <?php echo e($trades->appends(['sort' => $sort])->appends(['order' => $order])->links()); ?>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script>
    <?php if(in_array(auth()->user()->role, ['ADMIN', 'FLOOR_MANAGER'])){ ?>
    //function for updating status and salesperson using bulkupdate
    function updatepriceCOntroller(recId, data) {
      var data = {
        id: recId,
        price_open: data.replace(/[^\d.]/g, ''),
        _token: "<?php echo e(csrf_token()); ?>"
      }

      $.ajax({
        url: "<?php echo e(url('competitions/update')); ?>",
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        type: 'post',
        data: data,
        success: function(data) {
          $('html').find('[data-id="' + recId + '"]').css({border: '1px solid green'});
        },
        error: function(request, error) {

        }
      });

    }
    $(function() {
      $('.openpricechange').focusout(function() {
        let previousVal = $(this).attr('data-originalVal').trim();
        let recId = $(this).attr('data-id').trim();
        let currentVal = $(this).val().trim();
        if(previousVal != currentVal) {
          updatepriceCOntroller(recId, currentVal);
        }
      });
    });
    <?php } ?>
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>