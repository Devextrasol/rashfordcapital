<!--   ------Footer ------ -->
<footer class="footer-contact-us">
  <div class="content-wraper">
    <div class="ui two column doubling stackable grid container">
        <div class="column">
          <div class="footer-logo"><a href="<?php echo e(route('frontend.index')); ?>"><img src="<?php echo e(asset('images/contactuslog1.png')); ?>" alt="" class="home-logo my-logo"></a></div>
        </div>
        <div class="column footer-col">
          <div class="socal-media">
            <h2 style="text-align: center;">Follow Us On</h2>
            <div class="icons">
            <a href="#" title="Facebook" style="margin-right: 35px;"><i class="facebook f icon"></i></a>
            <a href="" title="Twitter"><i class="twitter icon"></i></a>
          </div>
        </div>
        </div>
      </div>
  </div>
      <div class="ui container footer-content">
        <p>Remember, Crypto Trading CFD is a leveraged product and can cause you to lose all your capital. Trading with Crypto Trading CFD may not be suitable for you</p>
          <p>Please make sure you fully understand the risks involved.</p>
          <p>Rashfordcapital services are mostly paid by using the Offer</p>
          <p>Rashfordcapital is a trademark of Rashfordcapital Ltd.</p>
          <p>SSL protected .</p>
    </div>
    <div class="footer-menu">
      <div class="ui two column doubling stackable grid container">
        <div class="nine wide column">
            <ul>
                <li><a href="<?php echo e(url('page/about-us')); ?>">About Us</a></li>
                <li><a href="<?php echo e(url('page/terms-of-use')); ?>">AML Policy</a></li>
                <li><a href="<?php echo e(url('page/privacy-policy')); ?>">Privacy Policy</a></li>
                <li><a href="<?php echo e(url('page/terms-of-use')); ?>">Terms and Conditions</a></li>
                <li><a href="<?php echo e(url('page/contact-us')); ?>">Contact Us</a></li>
            </ul>
        </div>
        <div class="seven wide column">
          <p>Copyright: Rashfordcapital. All rights reserved.</p>
        </div>
      </div>
    </div>
</footer>
