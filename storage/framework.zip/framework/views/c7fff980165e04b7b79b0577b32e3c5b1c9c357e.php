<?php $__env->startSection('title'); ?>
  <?php echo e(__('accounting::text.deposits')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php
  $role = auth()->user()->role;
  $roleAllowed = ['ADMIN', 'FLOOR_MANAGER'];

  ?>
  <div class="ui one column tablet stackable grid container">

    <button style=" margin-left: 17px;border: 1px solid #569211; padding: 7px 10px; border-radius: 3px; color: white; background-color: #8BC34A;" class="btn btn-xs btn-success custombtn open-model">New deposit</button>
    <div class="ui basic modal">
      <div class="ui icon header ">
        <i class="archive icon"></i>
        New Deposit
      </div>
      <div class="content">
        <form class="ui form modalcustom" action="<?php echo e(url('admin/deposits/newdeposit')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="field">
            <div class="two fields">
              <div class="field">
                <label>Amount</label>
                <input type="number" name="amount" placeholder="amount">
              </div>
              <div class="field">
                <label>Currency</label>
                <select class="ui fluid dropdown" name="currency">
                  <?php
                  $paymentMethodCurrencies = DB::select("select  * from currencies where code like 'BTC' OR code like 'eth' OR code like 'ltc'");
                  if (is_array($paymentMethodCurrencies) && count($paymentMethodCurrencies) > 0) {
                    foreach ($paymentMethodCurrencies as $r) {
                      echo "<option value='$r->code'>$r->code</option>";
                    }
                  } ?>
                </select>
              </div>
            </div>
            <div class="two fields">
              <div class="field">
                <label>User</label>
                <select class="ui fluid select2" name="user"  >
                  <?php
                  $users = DB::select("select  * from users ");
                  if (is_array($users) && count($users) > 0) {
                    foreach ($users as $r) {
                      echo "<option value='$r->email'>$r->email</option>";
                    }
                  } ?>
                </select>
              </div>
              <div class="field">

              </div>
            </div>
          </div>

          <button class="ui button" type="submit" tabindex="0">Deposit</button>
        </form>


      </div>
      <?php if(in_array($role, $roleAllowed)){ ?>
      <div class="actions">
        <div class="ui red basic cancel inverted button">
          <i class="remove icon"></i>
          Close
        </div>

      </div>
      <?php } ?>
    </div>
    <?php if(in_array($role, $roleAllowed)){ ?>
    <div class="column">
      <?php if($deposits->isEmpty()): ?>
        <div class="ui segment">
          <p><?php echo e(__('accounting::text.deposits_empty2')); ?></p>
        </div>
      <?php else: ?>
        <table class="ui selectable tablet stackable <?php echo e($inverted); ?> table">
          <thead>
          <tr>
            <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'user', 'sort' => $sort, 'order' => $order]); ?>
              <?php echo e(__('accounting::text.user')); ?>

            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'payment_method', 'sort' => $sort, 'order' => $order]); ?>
              <?php echo e(__('accounting::text.payment_method')); ?>

            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'payment_id', 'sort' => $sort, 'order' => $order]); ?>
              <?php echo e(__('accounting::text.payment_id')); ?>

            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'status', 'sort' => $sort, 'order' => $order]); ?>
              <?php echo e(__('accounting::text.status')); ?>

            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'amount', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
              <?php echo e(__('accounting::text.amount')); ?>

            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'comment', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
              comment
            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'created', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
              <?php echo e(__('accounting::text.created')); ?>

            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'updated', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
              <?php echo e(__('accounting::text.updated')); ?>

            <?php echo $__env->renderComponent(); ?>
          </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td data-title="<?php echo e(__('accounting::text.user')); ?>">
                <a href="<?php echo e(route('backend.users.edit', [$deposit->user_id])); ?>">
                  <?php echo e($deposit->user_name); ?>

                </a>
              </td>
              <td data-title="<?php echo e(__('accounting::text.payment_method')); ?>"><?php echo e(__('accounting::text.method_' . $deposit->payment_method_id)); ?></td>
              <td data-title="<?php echo e(__('accounting::text.payment_id')); ?>"><?php echo e($deposit->external_id); ?></td>
              <td data-title="<?php echo e(__('accounting::text.status')); ?>"
                  class="<?php echo e($deposit->status == Packages\Accounting\Models\Deposit::STATUS_COMPLETED ? 'positive' : ($deposit->status == Packages\Accounting\Models\Deposit::STATUS_CANCELLED ? 'negative' : '')); ?>"><?php echo e(__('accounting::text.deposit_status_' . $deposit->status)); ?></td>
              <td data-title="<?php echo e(__('accounting::text.amount')); ?>" class="right aligned">

                <?php if($deposit->account_currency_code != $deposit->payment_currency_code): ?>
                  <span
                      data-tooltip="<?php echo e(__('accounting::text.deposit_amount_tooltip', ['amount' => $deposit->_payment_amount, 'ccy' => $deposit->payment_currency_code, 'ccy1' => $deposit->account_currency_code, 'ccy2' => $deposit->payment_currency_code, 'x' => $deposit->payment_fx_rate])); ?>">
                                        <i class="calculator tooltip icon"></i>
                                    </span>
                <?php endif; ?>
                <?php echo e($deposit->_amount); ?> <?php echo e($deposit->account_currency_code); ?>

              </td>
              <td>
                <button class="ui olive basic button" type="button" onclick="return showComment('<?php echo e($deposit->id); ?>' , '<?php echo e(base64_encode($deposit->comment)); ?>' )"><i class="comment icon"></i>
                </button>
              </td>
              <td data-title="<?php echo e(__('accounting::text.created')); ?>" class="right aligned">
                
                <span data-tooltip="<?php echo e($deposit->created_at); ?>">
                                    <i class="calendar outline tooltip icon"></i>
                                </span>
              </td>
              <td data-title="<?php echo e(__('accounting::text.updated')); ?>" class="right aligned">
                
                <span data-tooltip="<?php echo e($deposit->updated_at); ?>">
                                    <i class="calendar outline tooltip icon"></i>
                                </span>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
    <?php if(isset($deposits_temp) && count($deposits_temp) > 0 ){ ?>
    <div class="column">
      <h2>Pending Payments</h2>
      <table class="ui selectable tablet stackable <?php echo e($inverted); ?> table">
        <thead>
        <tr>
          <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'user', 'sort' => $sort, 'order' => $order]); ?>
            <?php echo e(__('accounting::text.user')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'payment_method', 'sort' => $sort, 'order' => $order]); ?>
            <?php echo e(__('accounting::text.payment_method')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'payment_id', 'sort' => $sort, 'order' => $order]); ?>
            <?php echo e(__('accounting::text.payment_id')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'status', 'sort' => $sort, 'order' => $order]); ?>
            <?php echo e(__('accounting::text.status')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'amount', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
            <?php echo e(__('accounting::text.amount')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'created', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
            <?php echo e(__('accounting::text.created')); ?>

          <?php echo $__env->renderComponent(); ?>
          <?php $__env->startComponent('components.tables.sortable-column', ['id' => 'updated', 'sort' => $sort, 'order' => $order, 'class' => 'right aligned']); ?>
            Status
          <?php echo $__env->renderComponent(); ?>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $deposits_temp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td data-title="<?php echo e(__('accounting::text.user')); ?>">
              <a href="<?php echo e(route('backend.users.edit', [$deposit->user_id])); ?>">
                <?php echo e($deposit->user_name); ?>

              </a>
            </td>
            <td data-title=""><?php $methodName = \Illuminate\Support\Facades\DB::table('payment_methods')->where('id', $deposit->payment_method_id)->first();
              echo (isset($methodName->code)) ? $methodName->code : 'N/A';
              ?></td>
            <td data-title="<?php echo e(__('accounting::text.payment_id')); ?>"><?php echo e($deposit->external_id); ?></td>
            <td data-title="<?php echo e(__('accounting::text.status')); ?>"
                class="<?php echo e($deposit->status == Packages\Accounting\Models\Deposit::STATUS_COMPLETED ? 'positive' : ($deposit->status == Packages\Accounting\Models\Deposit::STATUS_CANCELLED ? 'negative' : '')); ?>"><?php echo e(__('accounting::text.deposit_status_' . $deposit->status)); ?></td>
            <td data-title="<?php echo e(__('accounting::text.amount')); ?>" class="right aligned">
              <?php if($deposit->account_currency_code != $deposit->payment_currency_code): ?>
                <span
                    data-tooltip="<?php echo e(__('accounting::text.deposit_amount_tooltip', ['amount' => @$deposit->payment_amount, 'ccy' => $deposit->payment_currency_code, 'ccy1' => $deposit->account_currency_code, 'ccy2' => $deposit->payment_currency_code, 'x' => $deposit->payment_fx_rate])); ?>"> <i
                      class="calculator tooltip icon"></i> </span>
              <?php endif; ?>
              <?php echo e(@$deposit->amount); ?> <?php echo e($deposit->account_currency_code); ?>

            </td>
            <td data-title="<?php echo e(__('accounting::text.user')); ?>">
              <a href="<?php echo e(route('backend.users.edit', [$deposit->user_id])); ?>">
                <?php echo e($deposit->created_at); ?>

              </a>
            </td>

            <td data-title="<?php echo e(__('accounting::text.updated')); ?>" class="right aligned">
              
              <span data-tooltip="<?php echo e($deposit->updated_at); ?>">
                                     <button style=" border: 1px solid #569211; padding: 7px 10px; border-radius: 3px; color: white; background-color: #8BC34A;" class="btn btn-xs btn-success custombtn"
                                             onclick="return savePayment(<?= $deposit->id ?>)">Clear Payment</button>
                                </span>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <?php } ?>
    <div class="right aligned column">
      <?php echo e($deposits->appends(['sort' => $sort])->appends(['order' => $order])->links()); ?>

    </div>
    <?php } ?>
  </div>
  <div class="ui modaldeposit" style="display: none">
    <i class="close icon"></i>
    <div class="header">
      Add Comment
    </div>
    <div class="image content">

      <div class="description" style="width: 100%">
        <div class="ui header">
          <!-- simple form -->
          <form class="" role="form" method="post" action="">
            <input type="hidden" name="id" value="" id="depositId"/>
            <?php echo e(csrf_field()); ?>

            <p id="user_com_pre"></p>
            <textarea name="val" id="comment" cols="30" rows="10" style="margin: 0px;width: 806px;height: 118px;"></textarea>
            <p>
              <button class="ui positive right labeled icon button" type="button" onclick="return updateCommnt(this)" style="padding: 10px;"> Update <i class="checkmark icon"></i></button>
            </p>
          </form>

        </div>
      </div>
    </div>
    <div class="actions">

    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  <script>
    function showComment(transactionId, com) {
      $('.ui.modaldeposit').modal('show');
      $('#depositId').val(transactionId);
      $('#comment').text(atob(com))
    }

    function updateCommnt(e) {
      let formData = $(this).closest('form');
      var dt = new Date();
      $.post('<?php echo e(url('admin/user/updateDepositComment')); ?>', {
        id: $('html').find('#depositId').val(),
        comment: $('html').find('#comment').val(),
        _token: '<?php echo e(csrf_token()); ?>',
      }, function(res) {
        $('.ui.modal').modal('hide');
        window.location.reload();
        console.log(res);
      });
    }
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>