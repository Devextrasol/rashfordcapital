<?php $__env->startSection('title'); ?>
<?php echo e(__('auth.login')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('before-auth'); ?>
<div id="particles"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('auth'); ?>
<!-- --------Header------------->
<header class="branding">
  <div class="custom-container ui container">
    <a href="<?php echo e(route('frontend.index')); ?>"><img src="<?php echo e(asset('images/home-logo.png')); ?>" class="login-logo main-logo" alt=""></a>
  </div>
</header>
<!------------ Body---------------->
<article>
  <div class="custom-column ui container">
    <div class="ui stackable two column grid">
      <div class="nine wide column"><div class="care-center-2">
        <img src="<?php echo e(asset('images/login-illustration_03.png')); ?>" class="ui fluid image care-img" alt="">
      </div>
    </div>
    <div class="custom-style seven wide column">
      <div class="sign-up-form">
        <?php $__env->startComponent('components.session.messages'); ?>
        <?php echo $__env->renderComponent(); ?>
        <loading-form v-cloak inline-template>
        <form class="" method="POST" action="<?php echo e(route('login')); ?>" @submit="disableButton">
          <?php echo e(csrf_field()); ?>

          <h2 class="plz-login">Please Login Your Account!</h2>
          <p class="no-account">Don't have an account? <br class="desktop only"> Create your account, it takes less then a minute.</p>
          <a href="<?php echo e(route('register')); ?>" class="sign-up form-button">Sign Up</a>

          <div class="field">
            <?php
            $debug = true;
            if($debug){
              //$email = 'faisal.aqurz@gmail.com';
              //$pass = 'admin';
            }
            ?>
            <input type="text" name="email" id="email" placeholder="Enter <?php echo e(__('auth.email')); ?>" value="<?php echo e(old('email')); ?>" required value="<?php echo e(@$email); ?>">
            <label for="email"><?php echo e(__('auth.email')); ?> Address</label>
          </div>

          <div class="field">
            <input type="password" name="password" id="password" placeholder="Enter <?php echo e(__('auth.password')); ?>" required value="<?php echo e(@$pass); ?>">
            <label for="password"><?php echo e(__('auth.password')); ?></label>
          </div>

          <div class="field checkbox">

            <div class="ui checkbox">
              <input type="checkbox" name="remember" tabindex="0" class="hidden" <?php echo e(old('remember') ? 'checked="checked"' : ''); ?>>
              <label for="remember"><?php echo e(__('auth.remember')); ?></label>
            </div>
            <a href="<?php echo e(route('password.request')); ?>" class="forget-pass hover" >Forget Password</a>

          </div>


          <?php if(config('settings.recaptcha.public_key')): ?>
            <div class="field">
              <div class="g-recaptcha" data-sitekey="<?php echo e(config('settings.recaptcha.public_key')); ?>" data-theme="<?php echo e($inverted ? 'dark' : 'light'); ?>"></div>
            </div>
          <?php endif; ?>

          <button class="[{disabled: submitted, loading: submitted}, 'ui <?php echo e($settings->color); ?> fluid large submit button']" type="submit">Login</button>

          
          <a href="<?php echo e(url('page/terms-of-use')); ?>">Term and Conditions</a>
          <a href="<?php echo e(url('page/privacy-policy')); ?>">Privacy Policy</a>
        </form>
        </loading-form>
        <?php if (\Illuminate\Support\Facades\Blade::check('social')): ?>
        <div id="social-login-divider" class="ui horizontal divider">
          <?php echo e(__('auth.social_login')); ?>

        </div>
        <div>
          <?php if (\Illuminate\Support\Facades\Blade::check('social', 'facebook')): ?>
          <a href="<?php echo e(url('login/facebook')); ?>" class="ui circular facebook icon button">
            <i class="facebook icon"></i>
          </a>
          <?php endif; ?>
          <?php if (\Illuminate\Support\Facades\Blade::check('social', 'twitter')): ?>
          <a href="<?php echo e(url('login/twitter')); ?>" class="ui circular twitter icon button">
            <i class="twitter icon"></i>
          </a>
          <?php endif; ?>
          <?php if (\Illuminate\Support\Facades\Blade::check('social', 'linkedin')): ?>
          <a href="<?php echo e(url('login/linkedin')); ?>" class="ui circular linkedin icon button">
            <i class="linkedin icon"></i>
          </a>
          <?php endif; ?>
          <?php if (\Illuminate\Support\Facades\Blade::check('social', 'google')): ?>
          <a href="<?php echo e(url('login/google')); ?>" class="ui circular google plus icon button">
            <i class="google plus icon"></i>
          </a>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</article>
<!-----------End Body--------------->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/auth.js')); ?>"></script>
<?php if(config('settings.recaptcha.public_key')): ?>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth_new', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>