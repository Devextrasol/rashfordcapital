<th class="<?php echo e(isset($class) ? $class : ''); ?>">
	
    
    
        <?php echo e($slot); ?>

    
</th>